export async function onRequestGet() {
  return new Response('diag ok', { headers: { 'content-type': 'text/plain' } });
}
